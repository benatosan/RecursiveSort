#include "Select.h"

void Select::recursiveSelect(vector<int> &arr, int n, int &moves, int &comps, int &delays){
    int min = arr[n], index = 0;
    bool found = false;
    if (n == arr.size()-1){ //base case
         return;
    }
    //for loop goes through entire array and finds smallest value
    for (int i = n; i < arr.size(); i++){
        if(arr[i] < min){
            found = true;
            min = arr[i];
            index = i;
        }
        comps++;
    }
    if (found){ //swap smallest with first unsorted index
        swap(arr, index, n);
        moves++;
    }
    display(arr);
    delays++;
    recursiveSelect(arr, n+1, moves, comps, delays); //call recursively (moves up the array)
}