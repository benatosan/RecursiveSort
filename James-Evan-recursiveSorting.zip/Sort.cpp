#include "Sort.h"
#include <stdlib.h>

using namespace std;

void Sort::swap(vector<int> &arr, int a, int b){
    int temp;
    temp = arr[b];
    arr[b] = arr[a];
    arr[a] = temp;
}

void Sort::display(vector<int> &arr){
    cout << endl << endl;
    for (int i = 0; i < arr.size(); i++){
        cout << "|";
        for(int j = 0; j < arr[i]; j++){
            cout << "=";
        }
        cout << endl;
    }
    chrono::microseconds timespan(300000); //delay for user to see steps
    this_thread::sleep_for(timespan);
}

int Sort::binarySrch(vector<int> &arr, int searched, int start, int end){
    if (end >= start){ //if the section being searched is not empty
        int split = (start+end) / 2; //split available section into 2
        if(arr[split] == searched){ //the searched for number is the split
            displayBin(arr, split, split); //highlight the split num in this case
            return split;
        } else if (searched > arr[split]){ //the searched number is larger than number at split
            displayBin(arr, split+1, end); //highlight > spllit
            return binarySrch(arr, searched, split+1, end); //search > split
        } else if (searched < arr[split]){ //the searched number is less than number at split
            displayBin(arr, start, split-1); //highlight < split
            return binarySrch(arr, searched, start, split-1); //search < split
        }
    }
    return -1; //this only happens if the searched for number is not in the array
}

void Sort::displayBin(vector<int> &arr, int start, int end){
    cout << endl << endl;
    for (int i = 0; i < arr.size(); i++){
        cout << "|";
        for(int j = 0; j < arr[i]; j++){
            if (i >= start && i <= end){ //if the indice is within the search parameters, "*"
                cout << "*";
            } else {                     //otherwise continue with "="
                cout << "=";
            }
        }
        cout << endl;
    }
    chrono::microseconds timespan(500000); //delay for user to be able to see
    this_thread::sleep_for(timespan);
}   