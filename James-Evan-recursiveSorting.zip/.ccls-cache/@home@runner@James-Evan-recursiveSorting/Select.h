//Select.h
#include "Sort.h"

class Select : public Sort{ //inherits sort (is a sort)
    public :
        //function to sort array with bubble sort recursively
        void recursiveSelect(vector<int> &arr, int n, int &moves, int &comps, int &delays);
};