// Evan James - Recursive Sort
// This program demonstrates 3 different sorting algorithms and then offers a
// binary search all of which is shown graphically (hence why the size of vector
// is 15)
#include "Bubble.h"
#include "Merge.h"
#include "Select.h"
#include <time.h>

using namespace std;
using namespace chrono;

int main() {
  // hard code size of the array (small for graphical display)
  const int nums = 15;
  // initialize a vector of size nums
  vector<int> arr(nums);
  // declaring and initializing variables
  Bubble bubble;
  Select select;
  Merge merge;
  Sort sort;
  int moves = 0;
  int comps = 0;
  int delays = 0; // this variable counts the amount of times display() is
                  // called so that                  system time can be
                  // calculated without the delays in the display function
  int choice;
  char search;
  int searchNum;
  bool valid = false;
  bool repeat = true;
  char repeatOpt;

  // setting rand() reference
  srand(time(0));

  while (repeat) {   // while the user says sort again
    while (!valid) { // needed to cover code, needs nested while loops for
                     // repeat option to work properly
      // load array with random numbers from 1 to 20
      for (int l = 0; l < nums; l++) {
        arr[l] = rand() % 20 + 1;
      }

      // prompts user for choice of sort type
      cout << "\nWhich type of sort would you like to use?\n1. Bubble "
              "sort\n2. Selection sort\n3. Merge sort\n";
      cin >> choice;
      if (choice > 3 || choice < 1) {
        cout << "invalid input\n";
        return -1; // error msg
      } else {
        valid = true;
      }
      // switch on the choice of sort algorithm
      switch (choice) {
      case 1: { // calls recursive sort, displays system run time and
                // graphic
        auto t1 = chrono::high_resolution_clock::now();
        bubble.recursiveBubble(arr, arr.size(), moves, comps, delays);
        auto t2 = chrono::high_resolution_clock::now();
        float runTime = duration_cast<microseconds>(t2 - t1).count();
        cout << "Run Time: " << runTime - (300000 * delays) << " μs" << endl;
        break;
      }
      case 2: { // calls recursive sort, displays system run time and
                // graphic
        auto t1 = chrono::high_resolution_clock::now();
        select.recursiveSelect(arr, 0, moves, comps, delays);
        auto t2 = chrono::high_resolution_clock::now();
        float runTime = duration_cast<microseconds>(t2 - t1).count();
        cout << "Run Time: " << runTime - (300000 * delays) << " μs" << endl;
        break;
      }
      case 3: { // calls recursive sort, displays system run time and
                // graphic
        int l = arr.size();
        auto t1 = chrono::high_resolution_clock::now();
        merge.useMerge(arr, moves, comps, delays);
        auto t2 = chrono::high_resolution_clock::now();
        float runTime = duration_cast<microseconds>(t2 - t1).count();
        cout << "Run Time: " << runTime - (300000 * delays) << " μs" << endl;
        break;
      }
      }
      // complete msg
      cout << "COMPLETE\n"
           << "\nMoves made: " << moves << "\nComparisons made: " << comps
           << endl;

      // prompts for binary search
      cout << "Would you like to search for a number(y/n)?" << endl;
      cin >> search;
      switch (search) {
      case 'y': { // enter number, binarySrch finds number and displays
                  // process
        cout << "Enter number you want to find: ";
        cin >> searchNum;
        int index = sort.binarySrch(arr, searchNum, 0, arr.size());
        if (index == -1) {
          cout << "number is not in this array";
        } else {
          cout << "('*' was the section being "
                  "searched)\n=====================\nnumber is at "
                  "index "
               << index << "\n=====================";
        }
        break;
      }
      default:
        break; // if not yes, break away
      }
    }
    // prompts for redo with a new array.
    cout << "\nWould you like to sort again(y/n)?" << endl;
    cin >> repeatOpt;
    switch (repeatOpt) {
    case 'y':
      repeat = true; // resets variables
      valid = false;
      moves = 0;
      comps = 0;
      delays = 0;
      cout << endl;
      break;
    default:
      repeat = false; // ends program
      break;
    }
  }
}