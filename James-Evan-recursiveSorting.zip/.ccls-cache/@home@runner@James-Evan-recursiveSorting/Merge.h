//Merge.h
#include "Sort.h"

class Merge : public Sort{
    private:
        vector<int> tempArr; //temporary array for merging
    public:
        //function splits arrays in halves for mergeArrays()
        void recursiveMerge(vector<int> &arr, int start, int end, int &moves, int &compares, int &delays);
        //merges 2 arrays into a sorted temporary array, then puts sorted into original array
        void mergeArrays(vector<int> &arr, int start, int mid, int end, int &moves, int &compares);
        //called in main(), resizes vectors to avoid segmentation fault
        void useMerge(vector<int> &arr, int &moves, int &compares, int &delays);
};