//Sort.h
#include <vector>
#include <iostream>
#include <chrono>
#include <thread>
#ifndef SORT_H
#define SORT_H

using namespace std;

//base class for all sorting algorithms
class Sort{
    public:
        //swaps the elements in 2 indices
        void swap(vector<int> &arr, int a, int b);
        //displays an array graphically
        void display(vector<int> &arr);
        //displays the part that binary search is searching through as "*"
        void displayBin(vector<int> &arr, int start, int end);
        //function to do binary search recursively
        int binarySrch(vector<int>&arr, int searched, int start, int end);
};
#endif