//Bubble.h
#include "Sort.h"

class Bubble : public Sort{ //inherits sort class (is a sort)
    public:
        //function to sort array with bubble sort recursively
        void recursiveBubble(vector<int> &arr, int n, int &moves, int &comps, int &delays);
};