#include "Merge.h"

void Merge::recursiveMerge(vector<int> &arr, int start, int end, int &moves, int &compares, int &delays){
    int splitPoint;

    if (end - start <= 1){ //if array has 2 left or less (base case)
        if (end - start == 1){ //check if there is 2 in the split
            compares++;
            if (arr[end] < arr[start]){ //swap if needed
                swap(arr, end, start);
                moves++;
            }
        }
    } else { 
        splitPoint = (start + end) / 2; //finds middle of the array (changes throughout recursion)
        recursiveMerge(arr, start, splitPoint, moves, compares, delays); //call for first half
        recursiveMerge(arr, splitPoint+1, end, moves, compares, delays); //call for second half
        mergeArrays(arr, start, splitPoint, end, moves, compares); //merge the splitted arrays to 1
    }
    display(arr); //display the array
    delays++;
}

void Merge::mergeArrays(vector<int> &arr, int start, int mid, int end, int &moves, int &compares){
    //initialization of variables so they may change without messing up the recursion
    int split = mid+1; 
    int front = start;

    for(int i = start; i <= end; i++){ //iterates through the array
        if (front <= mid && split <= end){ //if the 2 iterators are not at the end of their halves
            compares++;
            if(arr[front] < arr[split]){ //check if value at index front < index split
                tempArr[i] = arr[front++]; //load front into temp array
                moves++;
            } 
            else if (arr[split] <= arr[front]) { //same thing for other case
                tempArr[i] = arr[split++];
                moves++;
            }
        } else if (front <= mid && !(split <= end)){ //if split iterator reached the end and other hasnt
            tempArr[i] = arr[front++]; //load the rest of that iterator into temp array
            moves++;
        } else if (!(front <= mid) && split <= end){ //same thing for other case
            tempArr[i] = arr[split++];
            moves++;
        }
    }
    //for loop loads the sorted temp array into original array
    for (int j = start; j <= end; j++){
        arr[j] = tempArr[j];
    }
}

void Merge::useMerge(vector<int> &arr, int &moves, int &compares, int &delays){
    int length = arr.size(); //variable that function can change opposed to arr.size()
    tempArr.resize(arr.size()); //resize to avoid core dumped errors
    recursiveMerge(arr, 0, length-1, moves, compares, delays);
    tempArr.resize(0); //resize to 0 for next call
}
