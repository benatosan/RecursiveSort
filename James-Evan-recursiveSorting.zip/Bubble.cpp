#include "Bubble.h"

void Bubble::recursiveBubble(vector<int> &arr, int n, int &moves, int &comps, int &delays){
    
    if (n == 0){ //if reached end of array
        return;
    } else {
        for(int i = 0; i < n-1; i++){ //iterates along the non-sorted values in the array
            comps++;
            if (arr[i] > arr[i+1]){ //swap if the 2 values next to eachother are in the wrong order
                swap(arr, i, i+1);
                moves++;
                display(arr);
                delays++;
            }
        }
        recursiveBubble(arr, n-1, moves, comps, delays); //calls recursively(down because end                                                   will be sorted)
    }
}